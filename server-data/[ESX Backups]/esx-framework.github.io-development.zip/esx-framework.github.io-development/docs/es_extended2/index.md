---
title: Index
---

# ES Extended v2 Docs

This is the index page for the ES Extended documentation. Should be noted that we sometimes don't focus on updating the documentation the same time as we push new features & changes to our code.
