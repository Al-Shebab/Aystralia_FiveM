# HUD.RemoveElement

```lua
HUD.RemoveElement(name)
```
This function delete hud element on screen by name.

### Dependency
```lua
local HUD  = M('game.hud')
```


### Example
```lua
HUD.RemoveElement('JobHud')
```

