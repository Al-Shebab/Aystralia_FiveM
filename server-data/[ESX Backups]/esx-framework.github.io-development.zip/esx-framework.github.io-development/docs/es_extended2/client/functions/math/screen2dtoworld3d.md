# utils.math.screen2DToWorld3D

```lua
utils.math.screen2DToWorld3D(x, y, fov, near, far, right, forward, up, at)
```
This function are incomplete.

!!! warning
    *Function incomplete, doing more testing for a appropriate document.*

### Arguments
| Argument      | Data Type | Optional | Default Value | Explanation |
|---------------|-----------|----------|---------------|-------------|
| x | coords | No | - | No description  |
| y | int | No | - | No description  |
| fov | int | No | - | No description  |
| near | int | No | - | No description  |
| far | int | No | - | No description  |
| right | coords | No | - | No description  |
| forward | coords | No | - | No description  |
| up | coords | No | - | No description  |
| at | coords | No | - | No description |

### Dependency
```lua
local utils = M("utils")
```

### Example
```lua

```

[Improve this documentation](https://github.com/esx-framework/esx-framework.github.io/blob/development/docs/es_extended2/client/functions/math/screen2dtoworld3d.md)