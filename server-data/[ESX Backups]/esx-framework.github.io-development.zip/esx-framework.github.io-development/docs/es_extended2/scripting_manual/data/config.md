# Config

```lua
local module.Config = run('data/config.lua', {vector3 = vector3})['Config']
```

This function get the config for the module.

[Improve this documentation](https://github.com/esx-framework/esx-framework.github.io/blob/development/docs/es_extended2/scripting_manual/data/config.md)