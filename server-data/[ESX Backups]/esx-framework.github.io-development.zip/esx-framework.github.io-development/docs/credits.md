# Credits

Here is the wall of fame for everyone who has aided the project! We're linking to the GitHub accounts.

## Current ESX Staff Team

If you want to get in touch with us then the fastest way is to contact us via our development discord.

- [GiZz](https://github.com/indilo53): owner
- [FuraXx](https://github.com/FuraXx): administration
- [nearbyplayer](https://github.com/nearbyplayer): administration

## Contributors & Retired Staff Members

- [FuraXx](https://github.com/FuraXx)
- [RomainLanz](https://github.com/RomainLanz)
- [Renaiku](https://github.com/renaiku)
- [ig0ne](https://github.com/ig0ne)
- .flo
- [LuaDeldu](https://github.com/LuaDeldu)
- [ArkSeyonet](https://github.com/ArkSeyonet)
- [KandaSoranyan](https://github.com/KandaSoranyan)
- [TanguyOrtegat](https://github.com/TanguyOrtegat)
- [tracid56](https://github.com/tracid56)
- [AdrineX](https://github.com/AdrineX)
- [RedAlex](https://github.com/RedAlex)
- [LifeGoal](https://github.com/LifeGoal)
- [SaltyGrandpa](https://github.com/SaltyGrandpa)
- [Hawaii_Beach](https://github.com/ElPumpo)
- .. and many more!

## Translators

- [ddh3](https://github.com/ddh3)
- [deviljin112](https://github.com/deviljin112)
- [majormarcin](https://github.com/majormarcin)
- [rex2630](https://github.com/rex2630)
- [Oldarorn](https://github.com/Oldarorn)
- [psycodeliccircus](https://github.com/psycodeliccircus)
- [MHL1337](https://github.com/MHL1337)
- [Vanheden](https://github.com/Vanheden)
- [userMacieG](https://github.com/userMacieG)
- [redoper1](https://github.com/redoper1)
- .. and many more!

An absolute complete list of contributers to the ESX project can be found at the individual GitHub repos' insights (except the ones who have been contributing on old repos)
