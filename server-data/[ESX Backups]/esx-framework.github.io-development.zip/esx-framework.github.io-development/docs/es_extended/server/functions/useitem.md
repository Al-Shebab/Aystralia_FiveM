# ESX.UseItem

```lua
ESX.UseItem(playerId, itemName)
```

This function is to force a player to use an item.

## Arguments

| Argument | Data Type | Optional | Default Value | Explanation      |
|----------|-----------|----------|---------------|------------------|
| playerId | number    | No       | -             | Player server id |
| itemName | string    | No       | -             | An item          |
