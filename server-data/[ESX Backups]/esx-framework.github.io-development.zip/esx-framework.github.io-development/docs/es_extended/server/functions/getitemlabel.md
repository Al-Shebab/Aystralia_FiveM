# ESX.GetItemLabel

```lua
ESX.GetItemLabel(item)
```

This function returns an item label.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation |
|----------|-----------|----------|---------------|-------------|
| item     | string    | No       | -             | Item name   |
