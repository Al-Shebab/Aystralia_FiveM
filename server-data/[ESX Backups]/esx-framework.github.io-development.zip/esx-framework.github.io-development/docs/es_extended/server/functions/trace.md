# ESX.Trace

```lua
ESX.Trace(msg)
```

This function writes a trace if debugging is enabled in the configuration file.

## Arguments

| Argument | Data Type | Optional | Default Value | Explanation                  |
|----------|-----------|----------|---------------|------------------------------|
| msg      | (any)     | No       | -             | Anything to print to console |
