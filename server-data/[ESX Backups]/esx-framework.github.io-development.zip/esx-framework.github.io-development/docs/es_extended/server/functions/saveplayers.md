# ESX.SavePlayers

```lua
ESX.SavePlayers(cb)
```

This function saves all players to database. It is async, and a function (optional) is invoked once saving is complete.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation       |
|----------|-----------|----------|---------------|-------------------|
| cb       | function  | Yes      | -             | Callback function |