# xPlayer.setMoney

```lua
xPlayer.setMoney(money)
```

This function sets the player cash balance.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation               |
|----------|-----------|----------|---------------|---------------------------|
| money    | number    | No       | -             | New money amount          |
