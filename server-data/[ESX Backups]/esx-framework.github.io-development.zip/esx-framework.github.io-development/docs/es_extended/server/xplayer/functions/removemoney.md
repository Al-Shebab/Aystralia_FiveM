# xPlayer.removeMoney

```lua
xPlayer.removeMoney(money)
```

## Argument

| Argument | Data Type | Optional | Default Value | Explanation               |
|----------|-----------|----------|---------------|---------------------------|
| money    | number    | No       | -             | Amount of money to remove |
