# xPlayer.removeWeapon

```lua
xPlayer.removeWeapon(weaponName)
```

This function removes a weapon from the player.

## Argument

| Argument   | Data Type | Optional | Default Value | Explanation |
|------------|-----------|----------|---------------|-------------|
| weaponName | string    | No       | -             | Weapon name |
