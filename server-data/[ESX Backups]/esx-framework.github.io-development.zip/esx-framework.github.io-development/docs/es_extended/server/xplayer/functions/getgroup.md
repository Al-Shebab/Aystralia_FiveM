# xPlayer.getGroup

```lua
xPlayer.getGroup()
```

This function gets the current player group.
