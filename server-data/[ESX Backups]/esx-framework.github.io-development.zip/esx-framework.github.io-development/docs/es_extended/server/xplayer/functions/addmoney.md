# xPlayer.addMoney

```lua
xPlayer.addMoney(money)
```

This function adds money.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation  |
|----------|-----------|----------|---------------|--------------|
| money    | number    | No       | -             | Money amount |
