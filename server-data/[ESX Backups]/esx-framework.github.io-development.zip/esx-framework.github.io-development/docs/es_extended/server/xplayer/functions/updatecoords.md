# xPlayer.updateCoords

```lua
xPlayer.updateCoords(coords)
```

This is an internal function used to update player coords, do not use it.

## Argument

| Argument | Data Type     | Optional | Default Value | Explanation       |
|----------|---------------|----------|---------------|-------------------|
| coords   | table&vector3 | No       | -             | New player coords |
