# xPlayer.getIdentifier

```lua
xPlayer.getIdentifier()
```

This function returns the Rockstar identifier used
