# xPlayer.getMoney

```lua
xPlayer.getMoney()
```

This function gets the current cash balance.
