# xPlayer.setName

```lua
xPlayer.setName(newName)
```

This function sets the player name.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation     |
|----------|-----------|----------|---------------|-----------------|
| newName  | string    | No       | -             | New player name |
