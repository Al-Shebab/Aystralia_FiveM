# xPlayer.getWeight

```lua
xPlayer.getWeight()
```

This functions returns the current player weight in a `number` type, can be used to do calculations.
