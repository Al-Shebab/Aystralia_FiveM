# xPlayer.getName

```lua
xPlayer.getName()
```

> If you have [ESX identity](https://github.com/esx-framework/esx_identity) Installed, This will return the Character Name, If not, it will return the FiveM name.

