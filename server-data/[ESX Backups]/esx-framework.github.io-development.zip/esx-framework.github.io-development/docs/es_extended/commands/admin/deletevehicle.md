# Delete Vehicle

```
dv [radius]
```
```
cardel [radius]
```

This command deletes all vehicles within the radius.

## Arguments

| Argument   | Data Type | Optional | Default Value |          Explanation           |
|------------|-----------|----------|---------------|--------------------------------|
| Radius     | Number    | yes      | -             | the radius of cars to delete   |

###### Note

This may not work as intended when using a large radius.
