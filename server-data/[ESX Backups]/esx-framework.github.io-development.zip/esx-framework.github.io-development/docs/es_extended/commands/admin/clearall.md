
# Clear All

```
clearall 
```

This command clears the chat for all users.

