
# Save All

```
saveall
```

This command saves the playerdata of all connected users


