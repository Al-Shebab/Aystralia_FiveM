# Clear Inventory

```
clearinventory [ID]
```

This command clears the users inventory.

## Arguments

| Argument   | Data Type | Optional | Default Value |       Explanation         |
|------------|-----------|----------|---------------|---------------------------|
| ID         | number    | No       | -             | The ServerID of the user. |




