# Clear Loadout

```
clearloadout [ID]
```

This command removes all weapons from the user.

## Arguments

| Argument   | Data Type | Optional | Default Value |       Explanation         |
|------------|-----------|----------|---------------|---------------------------|
| ID         | number    | No       | -             | The ServerID of the user. |

###### Note

This remove **ALL** of the players weapons.
