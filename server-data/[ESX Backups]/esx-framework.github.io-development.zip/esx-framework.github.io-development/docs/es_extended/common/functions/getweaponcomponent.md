# ESX.GetWeaponComponent

```lua
ESX.GetWeaponComponent(weaponName, weaponComponent)
```

This function returns the weapon component object for a weapon. Includes the component label, name and hash key. See the weapon config file for the available components.