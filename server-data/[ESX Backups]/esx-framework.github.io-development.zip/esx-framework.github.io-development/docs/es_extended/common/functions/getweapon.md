# ESX.GetWeapon

```lua
ESX.GetWeapon(weaponName)
```

This function Returns The weapon and its full weapon name.