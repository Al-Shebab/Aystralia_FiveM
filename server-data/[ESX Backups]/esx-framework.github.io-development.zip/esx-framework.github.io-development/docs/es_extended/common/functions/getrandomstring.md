# ESX.GetRandomString

```lua
ESX.GetRandomString(length)
```

This function gets a random string, with the defined length.

#### ESX.GetRandomString Example

```lua
local str = ESX.GetRandomString(5)
```
