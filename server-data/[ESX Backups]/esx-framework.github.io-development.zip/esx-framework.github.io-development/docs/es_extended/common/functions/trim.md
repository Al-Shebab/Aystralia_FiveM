# ESX.Math.Trim

```lua
ESX.Math.Trim(value)
```

This function trims an text, removing all trailing whitespaces. Often used when sanitizing the `GetVehicleNumberPlateText()` native.