# ESX.GetWeaponLabel

```lua
ESX.GetWeaponLabel(weaponName)
```

This function gets the weapon label for a given weapon.

#### ESX.GetWeaponLabel Example

```lua
local label = ESX.GetWeaponLabel('WEAPON_ASSAULTRIFLE')
```
