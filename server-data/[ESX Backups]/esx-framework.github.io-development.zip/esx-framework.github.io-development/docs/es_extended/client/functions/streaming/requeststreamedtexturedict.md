# ESX.Streaming.RequestStreamedTextureDict

```lua
ESX.Streaming.RequestStreamedTextureDict(textureDict, cb)
```

This function requests and returns the texture directory parsed. This is commonly used when loading sprites, then draw them on screen using [DrawSprite()](https://runtime.fivem.net/doc/reference.html#_0xE7FFAE5EBF23D890), an example would be drawing a speedometer.
