# ESX.UI.Menu.GetOpened

```lua
ESX.UI.Menu.GetOpened(type, namespace, name)
```

This function gets all opened menus.
