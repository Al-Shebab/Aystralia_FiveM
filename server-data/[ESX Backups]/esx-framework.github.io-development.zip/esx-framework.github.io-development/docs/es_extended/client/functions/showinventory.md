# ESX.ShowInventory

```lua
ESX.ShowInventory()
```

This function shows the inventory.
