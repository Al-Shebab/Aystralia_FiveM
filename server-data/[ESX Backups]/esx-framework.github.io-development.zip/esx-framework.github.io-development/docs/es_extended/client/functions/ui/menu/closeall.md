# ESX.UI.Menu.CloseAll

```lua
ESX.UI.Menu.CloseAll()
```

This function closes all open menus.
