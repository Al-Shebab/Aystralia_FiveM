# ESX.UI.HUD.RemoveElement

```lua
ESX.UI.HUD.RemoveElement(name)
```

This function removes a HUD element.
