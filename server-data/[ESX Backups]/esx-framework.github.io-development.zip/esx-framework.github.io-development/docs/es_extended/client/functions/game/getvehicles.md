# ESX.Game.GetVehicles

```lua
ESX.Game.GetVehicles()
```

Returns all vehicles in the world.
