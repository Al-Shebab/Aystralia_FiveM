# ESX.Streaming.RequestAnimDict

```lua
ESX.Streaming.RequestAnimDict(animDict, cb)
```

This function requests and returns the nimation directory parsed. A very common usage it to play animations using [TaskPlayAnim()](https://runtime.fivem.net/doc/reference.html#_0xEA47FE3719165B94). You can use Alex Guirre's Animations List found on [Github](https://alexguirre.github.io/animations-list).
