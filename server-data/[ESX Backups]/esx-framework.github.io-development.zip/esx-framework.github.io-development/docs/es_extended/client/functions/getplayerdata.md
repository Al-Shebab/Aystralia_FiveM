# ESX.GetPlayerData

```lua
ESX.GetPlayerData()
```

This function gets player data.
