# ESX.Streaming.RequestModel

```lua
ESX.Streaming.RequestModel(model, cb)
```

This function requests and returns the specified model parsed, a very common usage is spawning objects, etc.
