# ESX.UI.HUD.UpdateElement

```lua
ESX.UI.HUD.UpdateElement(name, data)
```

This function updates HUD elements.
