# ESX.UI.HUD.SetDisplay

```lua
ESX.UI.HUD.SetDisplay(opacity)
```

This function sets the HUD opacity.
