# ESX.Game.GetPeds

```lua
ESX.Game.GetPeds(onlyOtherPeds)
```

This function gets all peds found in the game world.

## Argument

| Argument      | Data Type | Optional | Default Value | Explanation                               |
|---------------|-----------|----------|---------------|-------------------------------------------|
| onlyOtherPeds | boolean   | Yes      | nil           | Only return other peds than your own ped? |
