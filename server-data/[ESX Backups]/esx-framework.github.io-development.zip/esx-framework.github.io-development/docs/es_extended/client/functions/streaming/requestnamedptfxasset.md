# ESX.Streaming.RequestNamedPtfxAsset

```lua
ESX.Streaming.RequestNamedPtfxAsset(assetName, cb)
```
