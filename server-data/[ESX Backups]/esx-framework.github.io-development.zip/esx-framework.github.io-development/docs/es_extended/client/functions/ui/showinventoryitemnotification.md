# ESX.UI.ShowInventoryItemNotification

```lua
ESX.UI.ShowInventoryItemNotification(add, item, count)
```

This function shows an inventory item notification.
