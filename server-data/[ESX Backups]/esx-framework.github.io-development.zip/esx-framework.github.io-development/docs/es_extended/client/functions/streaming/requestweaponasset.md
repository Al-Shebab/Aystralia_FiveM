# ESX.Streaming.RequestWeaponAsset

```lua
ESX.Streaming.RequestWeaponAsset(weaponHash, cb)
```
