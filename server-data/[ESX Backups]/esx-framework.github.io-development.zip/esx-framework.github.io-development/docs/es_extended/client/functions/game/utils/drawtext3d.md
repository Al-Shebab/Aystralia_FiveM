# ESX.Game.Utils.DrawText3D

```lua
ESX.Game.Utils.DrawText3D(coords, text, size, font)
```

This function draws 3D text on the specified coords. Must be drawn every frame, ideally in a loop. `size` and `font` arguments are optional.
