# ESX.Game.DeleteObject

```lua
ESX.Game.DeleteObject(object)
```

This function deletes an object.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation       |
|----------|-----------|----------|---------------|-------------------|
| object   | string    | No       | -             | The object handle |
