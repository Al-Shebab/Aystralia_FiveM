# ESX.UI.Menu.RegisterType

```lua
ESX.UI.Menu.RegisterType(type, open, close)
```

This function registers a menu type.
