# ESX.UI.HUD.RegisterElement

```lua
ESX.UI.HUD.RegisterElement(name, index, priority, html, data)
```

This function registers a HUD element.
