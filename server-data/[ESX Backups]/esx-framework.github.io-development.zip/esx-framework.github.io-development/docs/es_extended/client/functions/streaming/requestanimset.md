# ESX.Streaming.RequestAnimSet

```lua
ESX.Streaming.RequestAnimSet(animSet, cb)
```

This function requests and returns the animation set parsed. Animation sets provide movement styles, commonly used with [SetPedMovementClipset()](https://runtime.fivem.net/doc/reference.html#_0xAF8A94EDE7712BEF).
