# ESX.UI.Menu.Open

```lua
ESX.UI.Menu.Open(type, namespace, name, data, submit, cancel, change, close)
```

This function opens a menu.
