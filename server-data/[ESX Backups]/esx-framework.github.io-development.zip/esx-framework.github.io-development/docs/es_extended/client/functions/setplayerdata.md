# ESX.SetPlayerData

```lua
ESX.SetPlayerData(key, val)
```

This function sets player data.
