# ESX.Game.DeleteVehicle

```lua
ESX.Game.DeleteVehicle(vehicle)
```

This function deletes the parsed vehicle.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation        |
|----------|-----------|----------|---------------|--------------------|
| vehicle  | string    | No       | -             | The vehicle handle |
