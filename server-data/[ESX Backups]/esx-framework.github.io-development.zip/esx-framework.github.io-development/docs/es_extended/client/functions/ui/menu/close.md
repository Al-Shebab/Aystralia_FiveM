# ESX.UI.Menu.Close

```lua
ESX.UI.Menu.Close(type, namespace, name)
```

This function closes a menu.
