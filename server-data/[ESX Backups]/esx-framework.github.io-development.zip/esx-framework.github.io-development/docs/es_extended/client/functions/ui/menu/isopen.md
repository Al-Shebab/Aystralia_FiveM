# ESX.UI.Menu.IsOpen

```lua
ESX.UI.Menu.IsOpen(type, namespace, name)
```

This function checks if a menu is open.
