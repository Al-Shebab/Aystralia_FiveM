# ESX.Scaleform.ShowTrafficMovie

```lua
ESX.Scaleform.ShowTrafficMovie(sec)
```

This function starts the traffic scaleform movie used in the campaign.

## Argument

| Argument | Data Type | Optional | Default Value | Explanation                       |
|----------|-----------|----------|---------------|-----------------------------------|
| sec      | number    | No       | -             | Time in seconds to show scaleform |
