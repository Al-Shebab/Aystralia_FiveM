# ESX.IsPlayerLoaded

```lua
ESX.IsPlayerLoaded()
```

This function checks if the player is loaded.
