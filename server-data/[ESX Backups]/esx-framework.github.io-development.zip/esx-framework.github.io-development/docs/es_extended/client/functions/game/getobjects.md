# ESX.Game.GetObjects

```lua
ESX.Game.GetObjects()
```

This function gets all objects found in the game world.
