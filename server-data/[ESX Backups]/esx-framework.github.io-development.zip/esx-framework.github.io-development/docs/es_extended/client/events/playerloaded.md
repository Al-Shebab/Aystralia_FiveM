# esx:playerLoaded

```lua
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(playerData)

end)
```

This event is triggered when the player has connected to the server
