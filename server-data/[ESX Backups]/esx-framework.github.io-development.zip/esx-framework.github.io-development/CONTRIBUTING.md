# Contributing to ESX Framework documentation

Thank you for taking the time to contribute!

Please don't file an issue to ask a question, this is what our [Discord](https://discord.gg/ztzKWAF) is for!

If you need support utilize our [Forum](https://forum.esx-framework.org).

When submitting a PR make sure you're using the `development` branch, any changes to the master branch will be denied.
