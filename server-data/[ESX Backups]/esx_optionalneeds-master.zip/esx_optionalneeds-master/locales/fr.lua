Locales['fr'] = {
	
	['used_beer'] = 'vous avez utilisé 1x ~y~Bière~s~',

}