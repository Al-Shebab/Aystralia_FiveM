Config = {}

Config.Locale = 'en'

Config.EnableAntiSpam = true
Config.WaitingTime = 20
Config.CommunityLink = 'COMMUNITY_LINK'
Config.PlayersToStartRocade = 32
