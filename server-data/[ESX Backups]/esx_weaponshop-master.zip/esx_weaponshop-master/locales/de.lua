Locales ['de'] = {
  ['buy_license'] = 'Waffenlizenz kaufen?',
  ['yes'] = '%s',
  ['no'] = 'Nein',
  ['weapon_bought'] = 'Gekauft für %s EUR',
  ['not_enough_black'] = 'Du hast nicht genug Schwarzgeld',
  ['not_enough'] = 'Du hast nicht genug Geld',
  ['already_owned'] = 'Du besitzt diese Waffe bereits',
  ['shop_menu_title'] = 'Geschäft',
  ['shop_menu_prompt'] = 'Drücke ~INPUT_CONTEXT~ um auf das Geschäft zuzugreifen.',
  ['shop_menu_item'] = '%s EUR',
  ['map_blip'] = 'Waffenladen',
}
