Locales ['es'] = {
  ['buy_license'] = '¿comprar la licencia de armas?',
  ['yes'] = '%s',
  ['no'] = 'no',
  ['weapon_bought'] = 'comprada por $%s',
  ['not_enough_black'] = 'usted no tiene ~r~suficiente~s~ dinero negro',
  ['not_enough'] = 'usted no tiene ~r~suficiente~s~ dinero',
  ['already_owned'] = '¡Ya dispones de esta arma!',
  ['shop_menu_title'] = 'tienda',
  ['shop_menu_prompt'] = 'presione ~INPUT_CONTEXT~ para acceder a la tienda.',
  ['shop_menu_item'] = '$%s',
  ['map_blip'] = 'ammu-Nation',
}
