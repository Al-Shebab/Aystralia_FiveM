Locales ['br'] = {
  ['buy_license'] = 'comprar licença de porte de arma?',
  ['yes'] = '%s',
  ['no'] = 'não',
  ['weapon_bought'] = 'comprado por %s R$',
  ['not_enough_black'] = 'você não tem dinheiro sujo suficiente',
  ['not_enough'] = 'você não tem dinheiro suficiente',
  ['already_owned'] = 'você já possui esta arma!',
  ['shop_menu_title'] = 'comprar',
  ['shop_menu_prompt'] = 'pressione ~INPUT_CONTEXT~ para comprar armas.',
  ['shop_menu_item'] = 'R$%s',
  ['map_blip'] = 'loja de Armas',
}
