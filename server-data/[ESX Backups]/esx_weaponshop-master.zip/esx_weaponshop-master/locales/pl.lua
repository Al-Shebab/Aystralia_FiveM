Locales ['pl'] = {
  ['buy_license'] = 'czy chcesz kupić licencję?',
  ['yes'] = '%s',
  ['no'] = 'nie',
  ['weapon_bought'] = 'purchased for %s PLN',
  ['not_enough_black'] = 'nie masz wystarczająco brudnej kasy',
  ['not_enough'] = 'nie masz wystarczająco pieniędzy',
  ['already_owned'] = 'you already own this weapon!',
  ['shop_menu_title'] = 'sklep',
  ['shop_menu_prompt'] = 'Wciśnij ~INPUT_CONTEXT~ aby otworzyć sklep.',
  ['shop_menu_item'] = '%s PLN',
  ['map_blip'] = 'sklep z bronią',
}
