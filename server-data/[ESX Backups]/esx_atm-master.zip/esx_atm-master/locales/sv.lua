Locales['sv'] = {
  ['invalid_amount'] = '~r~Det är en ogiltig summa pengar~s~',
  ['deposit_money']  = 'du satte in ~g~$%s~s~',
  ['withdraw_money'] = 'du har tagit ut ~g~$%s~s~', 
  ['press_e_atm']    = 'tryck ~INPUT_PICKUP~ för att komma åt denna ~g~ATM~s~',
  ['atm_blip']       = 'bankomat',
}
