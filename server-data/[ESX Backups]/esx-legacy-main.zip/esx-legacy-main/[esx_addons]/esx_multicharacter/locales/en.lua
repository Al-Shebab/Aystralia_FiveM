Locales['en'] = {
	['male'] = "Male",
	['female'] = "Female",
	['delete_label'] = "Delete %s %s?",
	['select_char'] = "Select Character",
	['create_char'] = "Create new character",
	['char_play'] = "Play this character",
	['char_delete'] = "Delete this character",
	['cancel'] = "Cancel",
	['confirm'] = "Confirm",
}
