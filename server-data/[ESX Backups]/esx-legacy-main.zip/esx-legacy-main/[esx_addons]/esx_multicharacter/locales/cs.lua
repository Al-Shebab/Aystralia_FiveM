Locales['cs'] = {
	['male'] = "Muž",
	['female'] = "Žena",
	['delete_label'] = "Vymazat %s %s?",
	['select_char'] = "Zvolit Postavu",
	['create_char'] = "Vytvořit novou postavu",
	['char_play'] = "Hrát za postavu",
	['char_delete'] = "Vymazat postavu",
	['cancel'] = "Zrušit",
	['confirm'] = "Potvrdit",
}
