const translate = new Object();

translate.name = "Nom";
translate.job = "Métier";
translate.bank = "Banque";
translate.money = "Argent";
translate.gender = "Sexe";
translate.dob = "Date de naissance";
