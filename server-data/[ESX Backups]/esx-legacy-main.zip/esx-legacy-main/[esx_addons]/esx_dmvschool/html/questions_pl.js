var tableauQuestion = [
	{
		question: "Jeśli masz 80 km/h, a zbliżasz się do terenu zabudowanego, musisz:",
		propositionA: "Przyspieszyć",
		propositionB: "Zahamować po czym jechać 50 km/h",
		propositionC: "Zwolnić",
		propositionD: "Zachować prędkość",
		reponse: "C"
	},

	{
		question: "Jeśli skręcasz w prawo na światłach bezkolizyjnych, ale widzisz przejście dla pieszych, co robisz:",
		propositionA: "Przepuszczam pieszego",
		propositionB: "Sprawdzam, czy w pobliżu nie ma innych pojazdów",
		propositionC: "Zachowuje szczególną ostrożność i przejeżdżam",
		propositionD: "Strzelam do pieszego i jadę dalej",
		reponse: "C"
	},

	{
		question: "Bez wcześniejszego wskazania prędkość w obszarze zabudowanym wynosi: __ km/h",
		propositionA: "40",
		propositionB: "50",
		propositionC: "60",
		propositionD: "70",
		reponse: "B"
	},

	{
		question: "Przed każdą zmianą pasa ruchu należy:",
		propositionA: "Spojżeć w lusterka",
		propositionB: "Sprawdź swoje martwe pole",
		propositionC: "Zasygnalizuj swoje zamiary",
		propositionD: "Wszystkie powyższe",
		reponse: "D"
	},

	{
		question: "Jaki poziom alkoholu we krwi NIE jest klasyfikowany jako jazda po pijanemu?",
		propositionA: "0.02%",
		propositionB: "0.19%",
		propositionC: "0.05%",
		propositionD: "0.04%",
		reponse: "A"
	},

	{
		question: "Kiedy możesz kontynuować jazdę na światłach?",
		propositionA: "Kiedy zaświeci się zielone",
		propositionB: "Kiedy nie ma nikogo na skrzyżowaniu",
		propositionC: "Kiedy zaświeci się żółte",
		propositionD: "Kiedy jest zielony lub czerwony ale skręcasz w prawo",
		reponse: "A"
	},

	{
		question: "Przewożąc ładunek gabarytowy możesz poruszać się tylko:",
		propositionA: "Drogami do tego przeznaczonymi",
		propositionB: "Nocami",
		propositionC: "Drogami ekspresowymi",
		propositionD: "Skrzyżowaniami o ruchu okrężnym",
		reponse: "B"
	},

	{
		question: "Posiadając prawo jazdy kategorii B możesz prowadzić :",
		propositionA: "Pojazd samochodowy o dopuszczalnej masie całkowitej nieprzekraczającej 3.5 t, z wyjątkiem autobusu i motocykla",
		propositionB: "Zespołem pojazdów złożonym z pojazdu, o którym mowa wyżej, oraz z przyczepy lekkiej",
		propositionC: "Zespołem pojazdów złożonym z pojazdu, o którym mowa wyżej, oraz z przyczepy innej niż lekka, o ile łączna dopuszczalna masa całkowita zespołu tych pojazdów nie przekracza 4250 kg",
		propositionD: "Wszystkie powyższe",
		reponse: "D"
	},

	{
		question: "Jedziesz autostradą, która wskazuje maksymalną prędkość 120 km/h. Większość aut jedzie z prędkością 140km/h, więc nie powinieneś jechać szybciej niż:",
		propositionA: "120 km/h",
		propositionB: "130 km/h",
		propositionC: "140 km/h",
		propositionD: "150 km/h",
		reponse: "A"
	},

	{
		question: "Wyprzedzając inne pojazdy należy:",
		propositionA: "Zwolnić",
		propositionB: "Trąbić na wyprzedzany pojazd",
		propositionC: "Oglądać wyprzedzany pojazd",
		propositionD: "Zwiększ prędkość",
		reponse: "D"
	},
]
