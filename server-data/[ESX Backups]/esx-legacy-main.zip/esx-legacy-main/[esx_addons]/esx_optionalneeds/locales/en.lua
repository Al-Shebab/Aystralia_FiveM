Locales['en'] = {
	
	['used_beer'] = 'you used 1x ~y~Beer~s~',

}