fx_version 'adamant'

game 'gta5'

description 'ESX Animations'

version 'legacy'

client_scripts {
	'@es_extended/imports.lua',
	'config.lua',
	'client/main.lua'
}

dependency 'es_extended'
