Locales['pl'] = {
  ['activated']   = 'aktywowano',
  ['deactivated'] = 'dezaktywano',
}
