Locales['sv'] = {
  ['skin_menu'] = 'skin meny',
  ['use_rotate_view'] = 'använd ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ och ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ för att rotera.',
  ['skin'] = 'ändra skin',
  ['saveskin'] = 'spara skin till fil',
}
