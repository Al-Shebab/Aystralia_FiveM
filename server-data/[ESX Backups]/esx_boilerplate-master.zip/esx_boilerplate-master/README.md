# fxserver-esx_boilerplate
FXServer ESX Boilerplate

This a sample script for es_extended
