---
id: why-performance
title: Why Performance?
---

[why-performance](unfinished-article)
