INSERT INTO `items` (name, label, `limit`) VALUES
	('apple', 'Apple', 50),
	('juice_apple', 'Apple juice', 10)
;