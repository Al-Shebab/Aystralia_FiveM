Locales['en'] = {
	['carry_for_leaves'] = 'Press ~INPUT_CONTEXT~ to catch fresh apples',
	['take_Apple_juice'] = 'Press ~INPUT_CONTEXT~ to make Apple Juice',
	['sell_Apple_juice'] = 'Press ~INPUT_CONTEXT~ to sell Apple Juice',
	['bag_full'] = 'You can not get more Apple because your bag is full.',
	['take_apple'] = '~y~Picking Apples~s~...',
	['you_do_not_have_enough_Apple'] = 'You do not have enough Apple.',
	['you_do_not_have_any_more_Apple'] = 'You Do not Have More ~r~Apple~s~',
	['transform_juice_apple'] = '~y~Wait To Transform For Fresh Apple Juice~s~...',
	['you_do_not_have_juice_apple'] = 'You Do not Have More ~r~Apple Juice~s~',
	['sell_juice'] = 'Sell ~y~x1~s~ ~y~Apple Juice~s~',
	['sell_juice_apple'] = '~g~To Sell Apple Juice ~s~...',
	-- Blips 
	['Apple_picking'] = 'Apple Picking Area',
	['turns_from_juice'] = 'Processing For Apple Juice',
	['sell_juice_apple_blip'] = 'Apple Juice Sale',
}
