# Arm-Wrestling
A Type Of Arm-Wrestling Script For Your FiveM Servers! This One's Standalone So No Framework Shit! lol

