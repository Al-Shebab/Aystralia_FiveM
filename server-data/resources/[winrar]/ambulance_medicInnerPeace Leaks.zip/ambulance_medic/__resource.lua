resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

description "NPC Medics, created by james for modit."

server_scripts {
    "server/*"
}

client_scripts {
    "client/*"
}

shared_scripts {
    "configs/*",
    "shared/*"
}



----Decoded by Lorenn rare5m.co Team---