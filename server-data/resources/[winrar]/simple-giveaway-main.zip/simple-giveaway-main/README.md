**feature**
* Custom Code , Money, and Language 
* Multi-Language (English, Chinese)
* SQL support
***
**requirements**
* [mysql-async](https://github.com/brouznouf/fivem-mysql-async)
* [es_extended(v1)](https://github.com/esx-framework/es_extended/tree/v1-final)
***
**Installation**
1. Download the file
2. Add all the files to the resources folder
3. Add the SQL files to the database
4. Add `start giveawaycode` to the server.cfg
***
**usage**

type command
```/code ```something you like
(e.g /code ABC-123)
***
**Configuration**

just setting something in ```config.lua```
