Locales['zh'] = {
    ['system'] = '领奖系统',
    ['max_use'] = '已超过使用次数',
    ['Successfully'] = '已成功领取',
    ['error'] = '兑换码错误'
}