Locales['en'] = {
    ['system'] = 'System',
    ['max_use'] = 'Has exceeded the number of uses',
    ['Successfully'] = 'Successfully receive',
    ['error'] = 'Error Code'
}