Config = {}
Config.Locale = 'zh' --language
Config.code = 'CVX-412' --code
Config.money = 1000 --givemoney
Config.Maxuse = 10 --max useage
--倒卖死全家 
--resell die mom
