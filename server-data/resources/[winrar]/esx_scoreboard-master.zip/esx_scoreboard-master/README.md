<div align="center">
  <a href="https://github.com/SadraKhorami/esx_scoreboard"><b>This project is include on my new GitHub</b></a><br><b>Dont forget The Star</b> 
  </div>
<h3 align="center">[ESX] FIVEM SCOREBOARD</h3>

  <p align="center">
    A user friendly scoreboard for your server ;)
    <br />
  don't forget the 🌟
   <!-- <a href="https://github.com/othneildrew/Best-README-Template"><strong>Explore the docs »</strong></a>
    <br />
    <br />
    <a href="https://github.com/othneildrew/Best-README-Template">View Demo</a>
    ·
    <a href="https://github.com/othneildrew/Best-README-Template/issues">Report Bug</a>
    ·
    <a href="https://github.com/othneildrew/Best-README-Template/issues">Request Feature</a> -->
  </p>
<p align="center">
  
  <a href="#">
    <img src="https://img.shields.io/badge/Language-Lua 5.4.3-00007C.svg?longCache=true&logo=Lua&logoColor=fafafa&style=for-the-badge">
  </a>
  <a href="#">
  <img src="https://img.shields.io/github/watchers/CF-TM/esx_scoreboard?label=PAGE%20VIEW&logo=github&style=for-the-badge" />
  </a>
  <a href="https://discord.gg/QhxE9pwwuM" target="_blank">
    <img src="https://img.shields.io/badge/DISCORD-grey?style=for-the-badge&logo=discord&logoColor=white&labelColor=5662F6">
  </a>
    <a href="https://instagram.com/crazyfox.exe" target="_blank">
    <img src="https://img.shields.io/badge/instagram-grey?style=for-the-badge&logo=instagram&logoColor=white&labelColor=F15680">
  </a>
</p>
<p align="center">
  <a href="https://github.com/CF-TM/esx_scoreboard" target="_blank">
    <img src="https://cdn.discordapp.com/attachments/690293292964773969/759700939661246484/crazyfox-min.png" alt="Logo" width="970" height="520">
  </a>
  </p>

## Features

- Optimized
- Animated Gradient
- responsiveed, Compatible with all resolutions
- Showing players name, id, internet connection stats
- Ability to scroll the list of players.
- Player time play
- job stats
- Robbery stats

## Installation

It is not difficult at all

```bash
  add 'esx_scoreboard' to your resources folder
```
Don't forget to configure the `server.cfg` file.
```bash
  Just put 'start esx_scoreboard' inside this file
```

## Support

For support, email support@foxteam.ir or join our [Discord](https://discord.gg/QhxE9pwwuM) channel.
      
  


  
